#!/usr/bin/env bash
# Test: doctor command
export ABP_ROOT="${ABP_ROOT:-$HOME/appbuilder-pro}"
export PATH="$PATH:$ABP_ROOT/bin"
bash "$ABP_ROOT/scripts/doctor.sh" &>/dev/null
echo "Doctor test passed"
